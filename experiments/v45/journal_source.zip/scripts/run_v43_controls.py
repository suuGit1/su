"""在v4.3公共服务投影环境中运行同信息MPC和单列Oracle对照。"""
import argparse
from dataclasses import fields
import hashlib
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from vpp_mappo.config import Config
from vpp_research.integrated import rollout


def run(a):
    root=Path(a.pilot);f=json.loads((root/'frozen.json').read_text());known={v.name for v in fields(Config)}
    c=Config(**{k:v for k,v in f['config'].items() if k in known})
    for k,v in f['config'].items():
        if k.startswith('_'):setattr(c,k,v)
    for path,sha in f['source_hashes'].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=sha:raise ValueError('试验实现变更')
    with zipfile.ZipFile('experiments/v42/dt_study_evidence.zip') as z:model=json.loads(z.read('residual.json'))
    out=root/a.method;out.mkdir(exist_ok=True);rows=[]
    csv=Path(c.train_csv).with_name('test.csv')
    for day in range(f['eval_days']):
        for i,w in enumerate([[.2,.3,.5],[.6,.1,.3],[.1,.7,.2]]):
            target=out/f'day_{day}_preference_{i}'
            if (target/'summary.json').exists():r=json.loads((target/'summary.json').read_text())
            else:r=rollout(c,model,target,method=a.method,preference=w,seed=40000+day,csv_path=csv,ev_bundle=c._ev_bundle,profile_index=day)
            rows.append(dict(day=day,preference=w,result=r))
    (out/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(a.method,len(rows))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pilot',default='runs/v43_pilot');p.add_argument('--method',choices=['mpc','milp_oracle'],required=True);run(p.parse_args())
