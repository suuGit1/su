"""统一配置；未知配置字段直接报错，避免参数拼写错误被忽略。"""
from dataclasses import dataclass, asdict
import json
from pathlib import Path
import math


@dataclass
class Config:
    algorithm: str = 'mappo'
    episodes: int = 100
    horizon: int = 96
    dt_hours: float = 0.25
    seed: int = 1
    hidden_size: int = 64
    ppo_epoch: int = 5
    num_mini_batch: int = 1
    lr: float = 0.0003
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_param: float = 0.2
    entropy_coef: float = 0.01
    reward_scale: float = 100.0
    violation_penalty: float = 100.0
    terminal_soc_penalty: float = 1000.0
    reserve_feasibility_only: bool = False
    terminal_soc_mode: str = 'legacy_penalty'
    terminal_soc_tolerance: float = 0.01
    safety: bool = True
    digital_twin: bool = False
    delay_steps: int = 0
    packet_loss: float = 0.0
    train_csv: str | None = None
    device: str = 'cpu'
    threads: int = 1
    network_model: str = 'aggregate'
    dispatch_spec: str | None = None
    solver_time_limit: float = 30.0
    metrics_enabled: bool = False
    objective_scales: tuple = (100.0, 100.0, 100.0)
    objective_weights: tuple = (1.0, 0.0, 0.0)
    reserve_hours: float = 0.25
    synthetic_carbon_g_per_kwh: float | None = None
    resource_model: str = 'legacy'
    flex_spec: str | None = None
    ev_sessions_path: str | None = None

    cyber_mode: str = 'off'
    cyber_dt_mode: str = 'physics'
    cyber_spec: str | None = None

    coordinator_priority_slack_fraction: float = 0.0
    coordinator_revision: str = 'legacy'
    coordinator_active_channels: tuple = (1,1,1,1,1,1)
    coordinator_payload_bound_bits: float = 8192.
    coordinator_mode: str = 'off'
    coordinator_aoi_limit_steps: float = 2.0
    coordinator_deadline_margin_steps: float = 1.0
    coordinator_soc_margin: float = 0.05
    coordinator_reserved_fraction: float = 0.5

    interval_safety: bool = False
    command_timing: bool = False
    downlink_bps: float = 10000.
    downlink_propagation_seconds: float = .02
    command_deadline_steps: float = 2.
    control_cycles: float = 1.e9
    risk_adaptive: bool = False
    task_focus: str = 'balanced'

    dt_interval_mode: str = 'constant'
    dt_scale_folds: int = 5
    safety_revision: int = 0
    research_version: int = 3
    rollout_episodes: int = 1
    validation_every: int = 0
    validation_days: int = 2
    target_kl: float = 0.02
    selection_hv_reference: tuple = (-100., -200., 0.)
    v4_action_bounds: bool = True
    v4_curtail_bias: float = 2.0

    paired_preference_days: bool = False
    exogenous_reward_centering: bool = False
    critic_initial_gain: float = 0.01
    critic_warmup_epochs: int = 0
    critic_extra_epochs: int = 0
    pareto_revision: str = 'legacy'
    learning_cleanup: bool = False
    pareto_fixed_preference: tuple = ()
    preference_schedule: str = 'legacy'

    def validate(self):
        if type(self.reserve_feasibility_only) is not bool:raise ValueError('备用纯可行性开关必须为布尔值')
        if not math.isfinite(self.coordinator_priority_slack_fraction) or not 0<=self.coordinator_priority_slack_fraction<=1:raise ValueError('协调优先级剩余额度比例必须在0至1之间')
        if self.terminal_soc_mode not in ('legacy_penalty','shared_band'):raise ValueError('未知终端库存协议')
        if not math.isfinite(self.terminal_soc_tolerance) or not 0<=self.terminal_soc_tolerance<=0.1:raise ValueError('终端SOC容差必须在0至0.1内')
        if self.terminal_soc_mode=='shared_band' and (self.resource_model!='sessions_v1' or self.research_version!=4):raise ValueError('公共终端协议要求v4会话资源模型')
        if type(self.paired_preference_days) is not bool:raise ValueError('配对日期开关必须为布尔值')
        if self.paired_preference_days and (self.research_version!=4 or self.preference_schedule!='balanced'):raise ValueError('配对日期要求v4分层偏好采样')

        if type(self.exogenous_reward_centering) is not bool:raise ValueError('外生奖励中心化开关必须为布尔值')
        if self.exogenous_reward_centering and self.research_version!=4:raise ValueError('奖励中心化只支持固定时域v4协议')

        if not math.isfinite(self.critic_initial_gain) or self.critic_initial_gain<=0:raise ValueError('critic初始化增益非法')
        for name in ('critic_warmup_epochs','critic_extra_epochs'):
            if type(getattr(self,name)) is not int or getattr(self,name)<0:raise ValueError('critic更新预算必须为非负整数')

        if self.pareto_revision not in ('legacy','conditioned_v44'):raise ValueError('未知Pareto学习版本')
        if self.preference_schedule not in ('legacy','balanced'):raise ValueError('未知偏好采样协议')
        if type(self.learning_cleanup) is not bool:raise ValueError('学习清理开关必须为布尔值')
        if self.pareto_fixed_preference:
            p=self.pareto_fixed_preference
            if len(p)!=3 or not all(math.isfinite(v) and v>=0 for v in p) or not math.isclose(sum(p),1):raise ValueError('固定诊断偏好非法')
            if self.pareto_revision!='conditioned_v44':raise ValueError('固定诊断偏好要求v44学习器')
        if self.learning_cleanup and (self.research_version!=4 or self.coordinator_revision!='public_service'):raise ValueError('学习清理要求v4与公开服务协调器')

        if self.coordinator_revision not in ('legacy','public_service'):raise ValueError('未知协调器版本')
        if len(self.coordinator_active_channels)!=6 or any(v not in (0,1) for v in self.coordinator_active_channels) or not self.coordinator_active_channels[2]:raise ValueError('有效通道掩码非法，负荷/电价通道必须保留')
        if not math.isfinite(self.coordinator_payload_bound_bits) or self.coordinator_payload_bound_bits<=0:raise ValueError('载荷上界必须为有限正数')
        if self.dt_interval_mode not in ('constant','adaptive') or self.dt_scale_folds<2:raise ValueError('DT 区间配置非法')
        if self.safety_revision not in (0,1):raise ValueError('安全修订必须为0或1')
        if self.research_version not in (3,4):raise ValueError('研究版本必须为3或4')
        for name in ('rollout_episodes','validation_days'):
            if type(getattr(self,name)) is not int or getattr(self,name)<1:raise ValueError(name+'必须为正整数')
        if type(self.validation_every) is not int or self.validation_every<0:raise ValueError('验证间隔必须非负')
        if not math.isfinite(self.target_kl) or self.target_kl<=0:raise ValueError('KL阈值必须为正')
        if len(self.selection_hv_reference)!=3 or not all(math.isfinite(x) for x in self.selection_hv_reference):raise ValueError('验证HV参考点非法')
        if type(self.v4_action_bounds) is not bool or not math.isfinite(self.v4_curtail_bias):raise ValueError('v4动作配置非法')
        if self.task_focus not in ('balanced','economic','carbon','reserve'):
            raise ValueError('未知协调任务')
        for name in ('downlink_bps','downlink_propagation_seconds','control_cycles'):
            if not math.isfinite(getattr(self,name)) or getattr(self,name)<0:raise ValueError(name+' 非法')
        if not math.isfinite(self.command_deadline_steps) or self.command_deadline_steps<=0:raise ValueError('命令期限必须为正')
        if self.coordinator_mode not in ('off','monitor','schedule'):
            raise ValueError('协调器模式必须为 off、monitor 或 schedule')
        if self.coordinator_mode!='off' and self.cyber_mode=='off':
            raise ValueError('协调器要求启用 C3 环境')
        for key in ('coordinator_aoi_limit_steps','coordinator_deadline_margin_steps','coordinator_soc_margin','coordinator_reserved_fraction'):
            if not math.isfinite(getattr(self,key)) or getattr(self,key)<0: raise ValueError(key+' 必须有限非负')
        if self.coordinator_aoi_limit_steps<=0 or self.coordinator_reserved_fraction>1:
            raise ValueError('AoI 阈值必须为正，保留资源比例不得超过 1')
        if self.cyber_mode not in ('off','fixed','joint') or self.cyber_dt_mode not in ('physics','hold'):
            raise ValueError('C3 模式或基础 DT 模式不合法')
        if self.cyber_mode!='off':
            if self.resource_model!='sessions_v1' or self.metrics_enabled:
                raise ValueError('C3 闭环要求 sessions_v1；多目标研究指标由 ResearchEnv 统一核算')
            if self.digital_twin or self.delay_steps or self.packet_loss:
                raise ValueError('C3 参数使用 cyber_spec/cyber_dt_mode；不能叠加旧模拟器参数')
        if self.resource_model not in ('legacy', 'sessions_v1'):
            raise ValueError('resource_model 必须为 legacy 或 sessions_v1')
        if self.resource_model == 'sessions_v1' and self.network_model not in ('ieee33', 'ieee69'):
            raise ValueError('会话资源模型要求 IEEE33/69')
        if self.resource_model == 'sessions_v1' and self.metrics_enabled and not math.isclose(self.reserve_hours,self.dt_hours):
            raise ValueError('会话模型当前备用持续时间必须等于一个调度步长')
        if self.network_model not in ('aggregate', 'ieee33', 'ieee69'):
            raise ValueError('network_model 必须为 aggregate、ieee33 或 ieee69')
        if not math.isfinite(self.solver_time_limit) or self.solver_time_limit <= 0:
            raise ValueError('求解时间必须为有限正数')
        if self.algorithm not in ('mappo', 'ippo', 'weighted_mappo'):
            raise ValueError('基础入口支持 mappo、ippo、weighted_mappo；Pareto 条件策略请用研究入口 --methods pareto')
        if type(self.metrics_enabled) is not bool:
            raise ValueError('metrics_enabled 必须为布尔值')
        if self.metrics_enabled and self.network_model not in ('ieee33', 'ieee69'):
            raise ValueError('三目标评价要求 IEEE33/69 统一模型')
        if self.algorithm == 'weighted_mappo' and not self.metrics_enabled:
            raise ValueError('固定权重多目标方法必须启用三目标评价')
        for name in ('objective_scales', 'objective_weights'):
            value = getattr(self, name)
            if len(value) != 3 or not all(math.isfinite(x) for x in value):
                raise ValueError(name + ' 必须为三个有限数')
        if min(self.objective_scales) <= 0 or min(self.objective_weights) < 0 or not math.isclose(sum(self.objective_weights), 1.0, abs_tol=1e-8):
            raise ValueError('目标尺度必须为正，偏好权重非负且和为 1')
        if not math.isfinite(self.reserve_hours) or self.reserve_hours <= 0:
            raise ValueError('备用持续时间必须为有限正数')
        if self.synthetic_carbon_g_per_kwh is not None and (not math.isfinite(self.synthetic_carbon_g_per_kwh) or self.synthetic_carbon_g_per_kwh < 0):
            raise ValueError('示例碳因子必须为有限非负数')
        if type(self.seed) is not int or self.seed < 0:
            raise ValueError('seed 必须为非负整数')
        for key in ('safety', 'digital_twin', 'interval_safety', 'command_timing', 'risk_adaptive'):
            if type(getattr(self, key)) is not bool:
                raise ValueError(key + ' 必须为布尔值')
        for key in ('episodes', 'horizon', 'hidden_size', 'ppo_epoch', 'num_mini_batch', 'threads'):
            v = getattr(self, key)
            if type(v) is not int or v < 1:
                raise ValueError(key + ' 必须为正整数')
        if self.horizon < 2 or self.num_mini_batch > 3 * self.horizon:
            raise ValueError('回合长度至少为 2，mini-batch 数不得超过样本数')
        if type(self.delay_steps) is not int or self.delay_steps < 0:
            raise ValueError('时延步数必须为非负整数')
        for key in ('lr', 'dt_hours', 'reward_scale', 'clip_param'):
            if not math.isfinite(getattr(self, key)) or getattr(self, key) <= 0:
                raise ValueError(key + ' 必须为有限正数')
        for key in ('gamma', 'gae_lambda', 'packet_loss'):
            if not 0 <= getattr(self, key) <= 1:
                raise ValueError(key + ' 必须在 0 到 1 之间')
        for key in ('violation_penalty', 'terminal_soc_penalty', 'entropy_coef'):
            if not math.isfinite(getattr(self, key)) or getattr(self, key) < 0:
                raise ValueError(key + ' 必须为有限非负数')
        return self

    @classmethod
    def load(cls, path):
        return cls(**json.loads(Path(path).read_text(encoding='utf-8'))).validate()

    def save(self, path):
        Path(path).write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding='utf-8')
